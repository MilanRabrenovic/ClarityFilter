ClarityFilter does not collect, transmit, sell, or share personal data.
- What’s stored: the list of keywords you add and the selected mode (Hide/Blur).
- Where: stored via browser storage on your device; if Sync is enabled, it may sync to your own account. The developer cannot access this data.
- Network: no requests to developer or third-party servers; no analytics; no ads.
- Retention: data remains until you remove it or uninstall the add-on.
Contact: developsolid@gmail.com