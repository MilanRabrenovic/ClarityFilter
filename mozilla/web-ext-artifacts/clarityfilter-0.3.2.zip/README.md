# ClarityFilter
Chrome extension to hide or block unwanted news containing certain keywords
