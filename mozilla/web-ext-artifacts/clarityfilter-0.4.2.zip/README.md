# ClarityFilter
Browser extension to hide or block unwanted news containing certain keywords
